En este ejercicio os pediré que creéis un programa que renombre una serie de ficheros. Se espera que en este ejercicio practiquéis lo que habéis aprendido de manipulación de ficheros y también de cadenas. 

Adjunto a este ejercicio hay un archivo comprimido que contiene una carpeta con diferentes archivos, esta carpeta contiene diferentes archivos con nombre 'archivo1.txt' hasta el numero 6. Estos archivos dentro de cada uno hay un texto que tenéis que leer con vuestro programa y cambiar el nombre de dicho archivo por el nombre que contiene este.

Por ejemplo, el archivo que se llama 'archivo1.txt' como contenido tiene: 'Primer_archivo.txt', pues una vez ejecutado vuestro programa este archivo se tiene que passar de 'archivo1.txt' -> 'Primer_archivo.txt' y hacerlo para todos los archivos que hay contenidos dentro de la carpeta.

Como _pista_, recordaros que tendréis que importar una o dos librerías, listar los archivos de un directorio e  cambiarlos de nombre. Para cambiar de nombre os puede servir también la función de mover.

Una vez finalizes el ejercicio, sube el archivo del programa comprimido en un zip.
