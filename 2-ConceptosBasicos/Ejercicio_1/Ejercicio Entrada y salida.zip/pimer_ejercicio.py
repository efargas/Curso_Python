print('Suma de dos números')
num1 = int(input('Introduce el primer número\n'))
num2 = int(input('Introduce el segundo número\n'))
res = num1 + num2
print(f'El resultado de sumar {num1} + {num2} = {res}')
